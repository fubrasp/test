package com.javagists.jerseyfilms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
/**
 * 
 * @author javagists.com
 *
 */
@SpringBootApplication
public class JerseyFilmsApplication {

    public static void main(String[] args) {
        SpringApplication.run(JerseyFilmsApplication.class, args);
    }
}
