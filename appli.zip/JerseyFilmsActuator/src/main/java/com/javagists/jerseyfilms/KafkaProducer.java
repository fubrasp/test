package com.javagists.jerseyfilms;

import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.serialization.LongSerializer;
import org.apache.kafka.common.serialization.StringSerializer;

import java.util.Properties;

public class KafkaProducer {

    private final static String TOPIC = "esgi";
    private final static String BOOTSTRAP_SERVERS =
            "192.168.56.210:9092";

    private static Producer<Long, String> createProducer() {
        Properties props = new Properties();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,
                BOOTSTRAP_SERVERS);
        props.put(ProducerConfig.CLIENT_ID_CONFIG, "KafkaExampleProducer");
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,
                LongSerializer.class.getName());
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
                StringSerializer.class.getName());
        return new org.apache.kafka.clients.producer.KafkaProducer<>(props);
    }

    public static void runProducer() throws Exception {
        final Producer<Long, String> producer = createProducer();
        long time = System.currentTimeMillis();

        try {
            final ProducerRecord<Long, String> record =
                    new ProducerRecord<>(TOPIC, time, "Hello World");

            // You can use metadata for debug
            RecordMetadata metadata = producer.send(record).get();
            System.out.println(metadata.toString());
        } finally {
            producer.flush();
            producer.close();
        }
    }
}
