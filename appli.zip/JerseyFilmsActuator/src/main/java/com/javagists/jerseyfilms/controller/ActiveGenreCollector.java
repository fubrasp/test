package com.javagists.jerseyfilms.controller;

import java.util.HashSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;

import com.javagists.jerseyfilms.model.Film;
import com.javagists.jerseyfilms.service.FilmService;
/**
 * 
 * @author javagists.com
 *
 */
@Component
public class ActiveGenreCollector implements HealthIndicator {

    @Autowired
    FilmService fs;

    @Override
    public Health health() {
        String status = "API is running";
        return new Health.Builder().up().withDetail("Status", status).build();
    }

}
