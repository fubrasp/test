package com.javagists.jerseyfilms.model;
/**
 * 
 * @author javagists.com
 *
 */
public enum Genre {
    ACTION, ADVENTURE, BIOGRAPHY, COMEDY, CRIME, DRAMA, HISTORICAL, HORROR, MUSICAL, SCIFI, WAR, WESTERN ;
}
